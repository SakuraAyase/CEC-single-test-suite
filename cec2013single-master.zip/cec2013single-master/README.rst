=============================================================
CEC'2013 Single Global Optimization Special Session Benchmark
=============================================================

This package wraps the official C code for the Special Session & Competition on Real-Parameter Single Objective Optimization at
the IEEE Congress on Evolutionary Computation. See http://www.ntu.edu.sg/home/EPNSugan/index_files/CEC2013/CEC2013.htm.

This package is a unofficial package using cython for calling the official implementation in C source code.
